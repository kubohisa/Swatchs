This folder contains L*a*b* colour values following the CIELAb model of 1976. 

The clf files can be opened in any text editor. 
1 line represents 1 colour, the structure is:

Colourname[tab]L-value[tab]L*-value[tab]a*-value[tab]b*-value
