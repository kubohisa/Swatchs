This folder contains GPL files for the opensource imageprocessing editor GIMP. 
