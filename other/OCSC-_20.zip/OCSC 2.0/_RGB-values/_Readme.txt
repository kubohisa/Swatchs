This folder contains RGB colour values following the standard RGB model from HP/Microsoft. 

The rgb files can be opened in any text editor. 
1 line represents 1 colour, its structure is:

Red-value[tab]Green-value[tab]Blue-value
