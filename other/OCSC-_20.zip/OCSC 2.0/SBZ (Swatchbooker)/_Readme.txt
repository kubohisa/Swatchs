This folder contains SBZ files following the Swatchbooker format. 
The included colour values are in the Lab format following the CIEL*a*b* definition of 1976.