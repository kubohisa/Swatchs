This folder contains ASE files following the Adobe Swatch Exchange format. 
The included colour values are in the Lab format following the CIEL*a*b* definition of 1976.