The SOC files included in this folder are intended for use with OpenOffice.org, Apache OpenOffice and LibreOffice and provide sRGB versions of the original LAB values. For LibreOffice 5.2.x we have included an installation instruction.

