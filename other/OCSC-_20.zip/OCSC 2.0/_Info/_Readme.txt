This folder contains colour system descriptions in German and English (producer contact address, number and type of colours).


