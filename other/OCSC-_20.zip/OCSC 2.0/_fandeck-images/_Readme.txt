This folder contains photos of many swatchbooks that are included in the OCSC 2.0.
